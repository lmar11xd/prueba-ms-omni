package com.lmar.dominioservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DominioServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
