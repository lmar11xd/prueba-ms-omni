package com.lmar.dominioservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DominioServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DominioServiceApplication.class, args);
	}

}
