package com.lmar.orquestadorservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrquestadorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
